package com.mealsync.controller;

import com.mealsync.model.Meal;
import com.mealsync.repository.MealRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/meals")
public class MealController {
    
    @Autowired
    private MealRepository mealRepository;
    
    @GetMapping
    public List<Meal> getAllMeals() {
        return mealRepository.findAll();
    }
}
