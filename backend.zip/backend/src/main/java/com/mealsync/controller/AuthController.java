package com.mealsync.controller;

import com.mealsync.model.User;
import com.mealsync.service.UserService;
import com.mealsync.repository.UserRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private UserRepository userRepository;

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody User user) {
        try {
            User savedUser = userService.registerUser(user);
            return ResponseEntity.ok(Map.of("message", "User registered successfully!", "userId", savedUser.getId()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String password = request.get("password");

        boolean isValid = userService.checkPassword(email, password);
        if (isValid) {
            User user = userRepository.findByEmail(email).get();
            return ResponseEntity.ok(Map.of(
                "message", "Login successful!", 
                "userId", user.getId(),
                "name", user.getName(),
                "role", user.getRole()
            ));
        } else {
            return ResponseEntity.status(401).body(Map.of("error", "Invalid email or password"));
        }
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String newPassword = request.get("newPassword");

        if (newPassword == null || newPassword.length() < 6) {
            return ResponseEntity.badRequest().body(Map.of("error", "Password must be at least 6 characters"));
        }

        boolean reset = userService.resetPassword(email, newPassword);
        if (reset) {
            return ResponseEntity.ok(Map.of("message", "Password reset successfully!"));
        } else {
            return ResponseEntity.badRequest().body(Map.of("error", "User not found!"));
        }
    }
}
