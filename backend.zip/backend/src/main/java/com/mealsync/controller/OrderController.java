package com.mealsync.controller;

import com.mealsync.dto.OrderRequest;
import com.mealsync.dto.OrderItemRequest;
import com.mealsync.model.Meal;
import com.mealsync.model.Order;
import com.mealsync.model.OrderItem;
import com.mealsync.model.User;
import com.mealsync.repository.MealRepository;
import com.mealsync.repository.OrderRepository;
import com.mealsync.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private MealRepository mealRepository;

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getUserOrders(@PathVariable Long userId) {
        List<Order> orders = orderRepository.findByUserIdOrderByOrderTimeDesc(userId);
        return ResponseEntity.ok(orders);
    }

    @PostMapping
    public ResponseEntity<?> placeOrder(@RequestBody OrderRequest request) {
        User user = userRepository.findById(request.getUserId()).orElse(null);
        if (user == null) {
            return ResponseEntity.badRequest().body("User not found");
        }

        Order order = new Order();
        order.setUser(user);
        order.setPickupSlot(request.getPickupSlot());
        order.setStatus("CONFIRMED");
        order.setOrderNumber("MS" + (10290 + (int)(Math.random() * 1000)));
        order.setQrCodeData(UUID.randomUUID().toString());

        double total = 0.0;
        for (OrderItemRequest itemReq : request.getItems()) {
            Meal meal = mealRepository.findById(itemReq.getMenuItemId()).orElse(null);
            if (meal != null) {
                OrderItem orderItem = new OrderItem();
                orderItem.setOrder(order);
                orderItem.setMeal(meal);
                orderItem.setQuantity(itemReq.getQty());
                orderItem.setPriceAtTimeOfOrder(meal.getPrice());
                
                order.getItems().add(orderItem);
                total += (meal.getPrice() * itemReq.getQty());
                
                // Update inventory
                int newQty = meal.getAvailableQuantity() - itemReq.getQty();
                meal.setAvailableQuantity(newQty);
                if (newQty <= 0) {
                    meal.setIsAvailable(false);
                }
                mealRepository.save(meal);
            }
        }
        order.setTotalAmount(total);

        Order savedOrder = orderRepository.save(order);
        return ResponseEntity.ok(savedOrder);
    }
}
