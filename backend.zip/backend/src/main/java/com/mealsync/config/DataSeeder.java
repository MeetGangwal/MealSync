package com.mealsync.config;

import com.mealsync.model.Meal;
import com.mealsync.repository.MealRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    @Autowired
    private MealRepository mealRepository;

    @Override
    public void run(String... args) throws Exception {
        if (mealRepository.count() == 0) {
            Meal m1 = new Meal();
            m1.setName("Maharashtrian Thali");
            m1.setCategory("thali");
            m1.setPrice(120.0);
            m1.setAvailableQuantity(50);
            m1.setIsAvailable(true);
            m1.setImageUrl("🍱");
            mealRepository.save(m1);
            
            Meal m2 = new Meal();
            m2.setName("Paneer Butter Masala");
            m2.setCategory("dishes");
            m2.setPrice(150.0);
            m2.setAvailableQuantity(30);
            m2.setIsAvailable(true);
            m2.setImageUrl("🍛");
            mealRepository.save(m2);

            Meal m3 = new Meal();
            m3.setName("Masala Dosa");
            m3.setCategory("dishes");
            m3.setPrice(80.0);
            m3.setAvailableQuantity(40);
            m3.setIsAvailable(true);
            m3.setImageUrl("🥞");
            mealRepository.save(m3);
            
            Meal m4 = new Meal();
            m4.setName("Cold Coffee");
            m4.setCategory("dishes");
            m4.setPrice(40.0);
            m4.setAvailableQuantity(100);
            m4.setIsAvailable(true);
            m4.setImageUrl("☕");
            mealRepository.save(m4);
        }
    }
}
