package com.mealsync.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    // The visual ID shown to users, e.g., MS10290
    private String orderNumber;
    
    // Connects this order to a specific User
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnoreProperties("password") // Prevent sending hashed passwords back to frontend
    private User user;
    
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties("order") // Prevent infinite JSON recursion
    private List<OrderItem> items = new ArrayList<>();
    
    // CONFIRMED, PARTIALLY_SERVED, COMPLETED, CANCELLED
    private String status;
    
    private Double totalAmount;
    
    // The data encoded in the QR ticket for this order
    private String qrCodeData;
    
    // The time pickup slot they selected
    private String pickupSlot;
    
    @CreationTimestamp
    private LocalDateTime orderTime;
}
